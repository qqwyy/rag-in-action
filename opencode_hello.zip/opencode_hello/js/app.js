const PHASE = {
    IDLE: 'idle',
    BUILDUP: 'buildup',
    SCANNING: 'scanning',
    SLOWDOWN: 'slowdown',
    LOCKED: 'locked',
    CELEBRATION: 'celebration'
};

class AudioManager {
    constructor() {
        this.audioContext = null;
        this.initialized = false;
    }

    init() {
        if (this.initialized) return;
        this.audioContext = new (window.AudioContext || window.webkitAudioContext)();
        this.initialized = true;
    }

    playScanSound(pitchMultiplier = 1) {
        if (!this.audioContext) this.init();
        const ctx = this.audioContext;
        const oscillator = ctx.createOscillator();
        const gainNode = ctx.createGain();

        oscillator.connect(gainNode);
        gainNode.connect(ctx.destination);

        oscillator.type = 'sine';
        oscillator.frequency.setValueAtTime(800 * pitchMultiplier, ctx.currentTime);
        oscillator.frequency.exponentialRampToValueAtTime(400 * pitchMultiplier, ctx.currentTime + 0.1);

        gainNode.gain.setValueAtTime(0.15, ctx.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.1);

        oscillator.start(ctx.currentTime);
        oscillator.stop(ctx.currentTime + 0.1);
    }

    playWinSound() {
        if (!this.audioContext) this.init();
        const ctx = this.audioContext;

        [523.25, 659.25, 783.99, 1046.50].forEach((freq, i) => {
            const oscillator = ctx.createOscillator();
            const gainNode = ctx.createGain();

            oscillator.connect(gainNode);
            gainNode.connect(ctx.destination);

            oscillator.type = 'triangle';
            oscillator.frequency.setValueAtTime(freq, ctx.currentTime);

            gainNode.gain.setValueAtTime(0, ctx.currentTime);
            gainNode.gain.linearRampToValueAtTime(0.2, ctx.currentTime + 0.1);
            gainNode.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 1.5);

            oscillator.start(ctx.currentTime + i * 0.05);
            oscillator.stop(ctx.currentTime + 1.5);
        });
    }

    playCoinSound() {
        if (!this.audioContext) this.init();
        const ctx = this.audioContext;
        const oscillator = ctx.createOscillator();
        const gainNode = ctx.createGain();

        oscillator.connect(gainNode);
        gainNode.connect(ctx.destination);

        oscillator.type = 'square';
        oscillator.frequency.setValueAtTime(988, ctx.currentTime);
        oscillator.frequency.setValueAtTime(1318.5, ctx.currentTime + 0.05);
        oscillator.frequency.setValueAtTime(1760, ctx.currentTime + 0.1);

        gainNode.gain.setValueAtTime(0.15, ctx.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.2);

        oscillator.start(ctx.currentTime);
        oscillator.stop(ctx.currentTime + 0.2);
    }

    playJumpSound() {
        if (!this.audioContext) this.init();
        const ctx = this.audioContext;
        const oscillator = ctx.createOscillator();
        const gainNode = ctx.createGain();

        oscillator.connect(gainNode);
        gainNode.connect(ctx.destination);

        oscillator.type = 'triangle';
        oscillator.frequency.setValueAtTime(880, ctx.currentTime);
        oscillator.frequency.linearRampToValueAtTime(1320, ctx.currentTime + 0.03);

        gainNode.gain.setValueAtTime(0.08, ctx.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.08);

        oscillator.start(ctx.currentTime);
        oscillator.stop(ctx.currentTime + 0.08);
    }
}

const audioManager = new AudioManager();

const COLORS = {
    CYAN: '#00fff5',
    PINK: '#ff2d95',
    GOLD: '#ffd700',
    WHITE: '#ffffff'
};

const state = {
    participants: [],
    winners: [],
    phase: PHASE.IDLE,
    winnerCount: 1,
    history: [],
    isStopping: false,
    isStarting: false
};

const grid = document.getElementById('grid');
const mainBtn = document.getElementById('main-btn');
const winnerCountEl = document.getElementById('winner-count');
const winnerBar = document.getElementById('winner-bar');
const overlayText = document.querySelector('.big-winner-text');
const overlayName = document.querySelector('.big-winner-name');
const totalEl = document.getElementById('total-count');
const remainingEl = document.getElementById('remaining-count');
const winnersEl = document.getElementById('winners-count');
const configModal = document.getElementById('config-modal');
const configTextarea = document.getElementById('participants-input');
const announcementOverlay = document.getElementById('announcement-overlay');

const defaultNames = [
    "赵一", "钱二", "孙三", "李四", "周五", "吴六", "郑七", "王八",
    "冯九", "陈十", "褚十一", "卫十二", "蒋十三", "沈十四", "韩十五", "杨十六",
    "朱十七", "秦十八", "尤十九", "许二十", "何廿一", "吕廿二", "施廿三", "张廿四",
    "孔廿五", "曹廿六", "严廿七", "华廿八", "金廿九", "魏三十", "陶三一", "姜三二",
    "戚三三", "谢三四", "邹三五", "喻三六", "柏三七", "水三八", "窦三九", "章四十",
    "云四一", "苏四二", "潘四三", "葛四四", "奚四五"
];

function init() {
    loadParticipants();
    renderGrid();
    updateStats();
    updateMainBtnState();

    mainBtn.addEventListener('click', handleMainBtnClick);
    document.getElementById('count-plus').addEventListener('click', () => adjustCount(1));
    document.getElementById('count-minus').addEventListener('click', () => adjustCount(-1));
    document.getElementById('config-toggle').addEventListener('click', toggleConfig);
    document.getElementById('fullscreen-toggle').addEventListener('click', toggleFullscreen);
    document.getElementById('save-config').addEventListener('click', saveConfig);
    document.getElementById('close-config').addEventListener('click', toggleConfig);

    configTextarea.value = state.participants.map(p => p.name).join('\n');
}

function loadParticipants() {
    const stored = localStorage.getItem('lottery_participants');
    if (stored) {
        const names = JSON.parse(stored);
        state.participants = names.map((name, i) => ({
            id: i,
            number: i + 1,
            name: name,
            status: 'idle'
        }));
    } else {
        state.participants = defaultNames.map((name, i) => ({
            id: i,
            number: i + 1,
            name: name,
            status: 'idle'
        }));
    }
}

function renderGrid() {
    grid.innerHTML = '';
    state.participants.forEach(p => {
        const cell = document.createElement('div');
        cell.className = `cell ${p.status === 'excluded' ? 'excluded' : ''} ${p.status === 'winner' ? 'winner' : ''}`;
        cell.id = `cell-${p.id}`;
        cell.innerHTML = `
            <div class="number">${p.number}</div>
            <div class="name">${p.name}</div>
        `;
        grid.appendChild(cell);
    });
}

function updateStats() {
    totalEl.textContent = state.participants.length;
    remainingEl.textContent = state.participants.filter(p => p.status === 'idle').length;
    winnersEl.textContent = state.winners.length;
}

function adjustCount(delta) {
    if (state.phase !== PHASE.IDLE) {
        return;
    }

    let newCount = state.winnerCount + delta;
    if (newCount < 1) newCount = 1;
    if (newCount > 10) newCount = 10;
    state.winnerCount = newCount;
    winnerCountEl.textContent = newCount;
}

function handleMainBtnClick() {
    if (state.phase === PHASE.IDLE) {
        if (state.isStarting) {
            return;
        }

        if (state.winners.length > 0) {
            resetLottery();
        } else {
            startLottery();
        }
    } else {
        state.isStopping = true;
    }
}

function updateMainBtnState() {
    if (state.phase === PHASE.IDLE) {
        if (state.winners.length > 0) {
            mainBtn.textContent = '重置系统';
            mainBtn.disabled = false;
            mainBtn.style.opacity = '1';
            mainBtn.classList.add('btn-reset');
            mainBtn.classList.remove('btn-stop');
        } else {
            mainBtn.textContent = '开始抽奖';
            mainBtn.disabled = false;
            mainBtn.style.opacity = '1';
            mainBtn.classList.remove('btn-reset', 'btn-stop');
        }
    } else {
        mainBtn.textContent = '停止抽奖';
        mainBtn.disabled = false;
        mainBtn.style.opacity = '1';
        mainBtn.classList.add('btn-stop');
        mainBtn.classList.remove('btn-reset');
    }
}

function showAnnouncement() {
    announcementOverlay.classList.add('show');
    return sleep(1200).then(() => {
        announcementOverlay.classList.remove('show');
    });
}

function showAnnouncementText(text) {
    announcementOverlay.querySelector('.announcement-text').textContent = text;
    announcementOverlay.classList.add('show');
    return sleep(1000).then(() => {
        announcementOverlay.classList.remove('show');
    });
}

async function startLottery() {
    if (state.phase !== PHASE.IDLE) return;
    if (state.isStarting) return;

    state.isStarting = true;

    const candidates = state.participants.filter(p => p.status === 'idle');
    if (candidates.length < state.winnerCount) {
        alert("剩余参与者人数不足！");
        state.isStarting = false;
        return;
    }

    updateMainBtnState();

    await showAnnouncement();

    for (let i = 0; i < state.winnerCount; i++) {
        if (state.isStopping) break;

        if (state.winnerCount > 1) {
            await showAnnouncementText(`抽取第 ${i + 1} 个名额`);
            await sleep(800);
        }
        await drawOne();

        if (state.isStopping) break;
        await sleep(2000);
    }

    if (state.isStopping) {
        stopLottery();
    } else {
        state.phase = PHASE.IDLE;
        document.body.style.boxShadow = '';
        updateMainBtnState();
    }

    state.isStarting = false;
}

async function drawOne() {
    state.phase = PHASE.BUILDUP;

    document.body.style.boxShadow = "inset 0 0 100px #000";
    audioManager.init();
    await sleep(800);

    if (state.isStopping) return;

    state.phase = PHASE.SCANNING;
    const candidates = state.participants.filter(p => p.status === 'idle');
    let scanDuration = 2000;
    let scanInterval = 60;
    let endTime = Date.now() + scanDuration;
    let lastCell = null;
    let lastSoundTime = 0;

    while (Date.now() < endTime) {
        if (state.isStopping) {
            if (lastCell) lastCell.classList.remove('active');
            return;
        }
        if (lastCell) lastCell.classList.remove('active');
        const randIndex = Math.floor(Math.random() * candidates.length);
        const p = candidates[randIndex];
        const cell = document.getElementById(`cell-${p.id}`);
        cell.classList.add('active');
        lastCell = cell;

        if (Date.now() - lastSoundTime > 80) {
            audioManager.playJumpSound();
            lastSoundTime = Date.now();
        }

        await sleep(scanInterval);
    }

    state.phase = PHASE.SLOWDOWN;
    let steps = 14;
    let delay = 60;

    const winnerIndex = secureRandom(candidates.length);
    const winner = candidates[winnerIndex];

    for (let i = 0; i < steps; i++) {
        if (state.isStopping) {
            if (lastCell) lastCell.classList.remove('active');
            return;
        }
        if (lastCell) lastCell.classList.remove('active');

        let p;
        if (i === steps - 1) {
            p = winner;
        } else {
            let idx = Math.floor(Math.random() * candidates.length);
            p = candidates[idx];
            while (p === winner && i < steps - 5) {
                idx = Math.floor(Math.random() * candidates.length);
                p = candidates[idx];
            }
        }

        const cell = document.getElementById(`cell-${p.id}`);
        cell.classList.add('active');
        lastCell = cell;

        if (i === steps - 1) {
            audioManager.playCoinSound();
        } else if (Date.now() - lastSoundTime > 100) {
            audioManager.playJumpSound();
            lastSoundTime = Date.now();
        }

        delay *= 1.18;
        await sleep(delay);
    }

    state.phase = PHASE.LOCKED;
    if (lastCell) lastCell.classList.remove('active');
    const winnerCell = document.getElementById(`cell-${winner.id}`);
    winnerCell.classList.add('winner');

    const rect = winnerCell.getBoundingClientRect();
    const cx = rect.left + rect.width / 2;
    const cy = rect.top + rect.height / 2;
    particleSystem.explode(cx, cy, COLORS.GOLD);

    await sleep(300);

    audioManager.playWinSound();

    await sleep(700);

    state.phase = PHASE.CELEBRATION;

    winner.status = 'winner';
    state.winners.push(winner);
    updateStats();

    showBigWinner(winner);
    particleSystem.fireConfetti();
    particleSystem.launchMultipleFireworks(5);

    addToWinnerBar(winner, state.winners.length);

    await sleep(3000);

    hideBigWinner();
}

function secureRandom(max) {
    const array = new Uint32Array(1);
    crypto.getRandomValues(array);
    return array[0] % max;
}

function showBigWinner(winner) {
    overlayText.textContent = winner.number;
    overlayName.textContent = winner.name;
    overlayText.classList.add('show');
    overlayName.classList.add('show');
}

function hideBigWinner() {
    overlayText.classList.remove('show');
    overlayName.classList.remove('show');
}

function addToWinnerBar(winner, rank) {
    winnerBar.classList.add('show');
    const card = document.createElement('div');
    card.className = 'winner-card';
    card.innerHTML = `
        <div class="rank">第${rank}名</div>
        <div class="info">
            <div class="w-name">${winner.name}</div>
            <div class="w-number">编号 ${winner.number}</div>
        </div>
    `;
    winnerBar.appendChild(card);
    winnerBar.scrollLeft = winnerBar.scrollWidth;
}

function resetLottery() {
    state.participants.forEach(p => p.status = 'idle');
    state.winners = [];
    state.phase = PHASE.IDLE;
    state.isStopping = false;
    state.isStarting = false;

    renderGrid();
    updateStats();

    winnerBar.innerHTML = '';
    winnerBar.classList.remove('show');

    updateMainBtnState();
}

function stopLottery() {
    state.isStopping = false;
    state.isStarting = false;
    state.phase = PHASE.IDLE;

    hideBigWinner();
    document.body.style.boxShadow = '';

    updateMainBtnState();
}

function toggleConfig() {
    const isOpen = configModal.classList.contains('open');
    if (isOpen) {
        configModal.classList.remove('open');
    } else {
        configModal.classList.add('open');
    }
}

function toggleFullscreen() {
    if (!document.fullscreenElement) {
        document.documentElement.requestFullscreen().catch(err => {
            console.log(`全屏失败: ${err.message}`);
        });
    } else {
        document.exitFullscreen();
    }
}

function saveConfig() {
    const text = configTextarea.value.trim();
    if (!text) return;
    
    const lines = text.split('\n').filter(l => l.trim());
    state.participants = lines.map((name, i) => ({
        id: i,
        number: i + 1,
        name: name.trim(),
        status: 'idle'
    }));
    
    localStorage.setItem('lottery_participants', JSON.stringify(lines));
    
    renderGrid();
    updateStats();
    toggleConfig();
}

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

class ParticleSystem {
    constructor() {
        this.canvas = document.getElementById('bg-canvas');
        this.ctx = this.canvas.getContext('2d');
        this.particles = [];
        this.resize();
        window.addEventListener('resize', () => this.resize());
        this.animate();
    }

    resize() {
        this.canvas.width = window.innerWidth;
        this.canvas.height = window.innerHeight;
    }

    animate() {
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
        
        if (state.phase === PHASE.IDLE && Math.random() < 0.1) {
            this.particles.push(new Particle(
                Math.random() * this.canvas.width,
                this.canvas.height + 10,
                COLORS.CYAN,
                'ambient'
            ));
        }

        for (let i = this.particles.length - 1; i >= 0; i--) {
            const p = this.particles[i];
            p.update();
            p.draw(this.ctx);
            if (p.life <= 0) this.particles.splice(i, 1);
        }

        requestAnimationFrame(() => this.animate());
    }

    explode(x, y, color) {
        for (let i = 0; i < 50; i++) {
            this.particles.push(new Particle(x, y, color, 'burst'));
        }
    }

    fireConfetti() {
        const colors = [COLORS.CYAN, COLORS.PINK, COLORS.GOLD, COLORS.WHITE];
        for (let i = 0; i < 200; i++) {
            const x = this.canvas.width / 2;
            const y = this.canvas.height / 2;
            const color = colors[Math.floor(Math.random() * colors.length)];
            this.particles.push(new Particle(x, y, color, 'confetti'));
        }
    }

    launchFirework(x, y) {
        const colors = [COLORS.CYAN, COLORS.PINK, COLORS.GOLD, COLORS.WHITE, '#ff6b6b', '#4ecdc4'];
        const color = colors[Math.floor(Math.random() * colors.length)];

        const startX = Math.random() * this.canvas.width;
        const startY = this.canvas.height + 50;

        const particle = new Particle(startX, startY, color, 'firework');
        particle.targetX = x;
        particle.targetY = y;
        this.particles.push(particle);
    }

    fireworkBurst(x, y, color) {
        for (let i = 0; i < 80; i++) {
            this.particles.push(new Particle(x, y, color, 'sparkle'));
        }
    }

    launchMultipleFireworks(count = 5) {
        for (let i = 0; i < count; i++) {
            const delay = (i + 1) * 200;
            setTimeout(() => {
                const x = (this.canvas.width * 0.2) + Math.random() * (this.canvas.width * 0.6);
                const y = (this.canvas.height * 0.2) + Math.random() * (this.canvas.height * 0.4);
                this.launchFirework(x, y);
            }, delay);
        }
    }
}

class Particle {
    constructor(x, y, color, type) {
        this.x = x;
        this.y = y;
        this.color = color;
        this.type = type;
        this.life = 1.0;
        this.hasExploded = false;

        if (type === 'ambient') {
            this.vx = (Math.random() - 0.5) * 1;
            this.vy = -Math.random() * 2 - 0.5;
            this.size = Math.random() * 2 + 1;
            this.decay = 0.005;
        } else if (type === 'burst') {
            const angle = Math.random() * Math.PI * 2;
            const speed = Math.random() * 10 + 2;
            this.vx = Math.cos(angle) * speed;
            this.vy = Math.sin(angle) * speed;
            this.size = Math.random() * 4 + 2;
            this.decay = 0.02;
            this.gravity = 0.1;
        } else if (type === 'confetti') {
            this.vx = (Math.random() - 0.5) * 30;
            this.vy = (Math.random() - 0.5) * 30;
            this.size = Math.random() * 6 + 3;
            this.decay = 0.01;
            this.gravity = 0.2;
            this.drag = 0.95;
        } else if (type === 'firework') {
            this.vx = (this.targetX - this.x) / 40;
            this.vy = (this.targetY - this.y) / 40;
            this.size = 4;
            this.decay = 0.002;
            this.trail = [];
        } else if (type === 'sparkle') {
            const angle = Math.random() * Math.PI * 2;
            const speed = Math.random() * 15 + 5;
            this.vx = Math.cos(angle) * speed;
            this.vy = Math.sin(angle) * speed;
            this.size = Math.random() * 3 + 1;
            this.decay = 0.015;
            this.gravity = 0.15;
            this.drag = 0.97;
        }
    }

    update() {
        this.x += this.vx;
        this.y += this.vy;
        this.life -= this.decay;

        if (this.type === 'firework') {
            this.trail.push({ x: this.x, y: this.y });
            if (this.trail.length > 10) this.trail.shift();

            const distToTarget = Math.sqrt(
                Math.pow(this.targetX - this.x, 2) +
                Math.pow(this.targetY - this.y, 2)
            );

            if (distToTarget < 10 && !this.hasExploded) {
                this.hasExploded = true;
                this.life = 0;
                particleSystem.fireworkBurst(this.targetX, this.targetY, this.color);
            }
        } else if (this.type === 'sparkle') {
            this.vy += this.gravity;
            this.vx *= this.drag;
            this.vy *= this.drag;
        } else if (this.type === 'burst' || this.type === 'confetti') {
            if (this.gravity) this.vy += this.gravity;
            if (this.drag) {
                this.vx *= this.drag;
                this.vy *= this.drag;
            }
        }
    }

    draw(ctx) {
        ctx.save();

        if (this.type === 'firework') {
            ctx.strokeStyle = this.color;
            ctx.lineWidth = 2;
            ctx.globalAlpha = this.life;
            ctx.beginPath();
            if (this.trail.length > 0) {
                ctx.moveTo(this.trail[0].x, this.trail[0].y);
                for (let i = 1; i < this.trail.length; i++) {
                    ctx.lineTo(this.trail[i].x, this.trail[i].y);
                }
            }
            ctx.stroke();

            ctx.fillStyle = '#fff';
            ctx.beginPath();
            ctx.arc(this.x, this.y, 3, 0, Math.PI * 2);
            ctx.fill();
        } else if (this.type === 'sparkle') {
            ctx.globalAlpha = this.life;
            ctx.fillStyle = this.color;
            ctx.shadowColor = this.color;
            ctx.shadowBlur = 10;
            ctx.beginPath();
            ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
            ctx.fill();
        } else {
            ctx.globalAlpha = this.life;
            ctx.fillStyle = this.color;

            if (this.type === 'confetti') {
                ctx.translate(this.x, this.y);
                ctx.rotate(this.life * 10);
                ctx.fillRect(-this.size/2, -this.size/2, this.size, this.size);
            } else {
                ctx.beginPath();
                ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
                ctx.fill();
            }
        }

        ctx.restore();
    }
}

const particleSystem = new ParticleSystem();

document.addEventListener('DOMContentLoaded', init);
